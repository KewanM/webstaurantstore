import io.cucumber.java.bs.A;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.implementation.bind.annotation.BindingPriority;
import org.apache.log4j.Priority;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Test2 {


    List<String> titles = new ArrayList<>();
    WebDriver driver;
@Ignore
    @Test
    public void test1_base() throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();


        driver.get("https://www.webstaurantstore.com");
        driver.manage().window().maximize();
        driver.findElement(By.id("searchval")).sendKeys("stainless work table");
        driver.findElement(By.id("searchval")).sendKeys(Keys.ENTER);

        List<WebElement> items = driver.findElements(By.xpath("//div[@id='product_listing']/div/div/a[@class='block']"));

        int counter=0;

        for(int i = 0; i<items.size();i++){
            WebDriverWait wait = new WebDriverWait(driver,10);
            wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//div[@id='product_listing']/div/div/a[@class='block']")).get(i)));
            items.get(i).click();
         //   driver.findElements(By.xpath("//div[@id='product_listing']/div/div/a[@class='block']")).get(i).click();
                        titles.add(driver.getTitle().toString());
                        driver.navigate().back();
                        counter++;


        }

        String lastPage = driver.findElement(By.xpath("//a[contains(@aria-label,'last page')]")).getText();
        int pages= Integer.valueOf(lastPage);



        while(pages>1){
            //Thread.sleep(3000);
            WebDriverWait wait = new WebDriverWait(driver,10);
            wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.cssSelector("#paging > nav > ul > li.inline-block.leading-4.align-top.rounded-r-md"))));

            driver.findElement(By.cssSelector("#paging > nav > ul > li.inline-block.leading-4.align-top.rounded-r-md")).click();
            for(int i = 0; i<items.size();i++) {
                wait = new WebDriverWait(driver, 10);
                wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//div[@id='product_listing']/div/div/a[@class='block']")).get(i)));
                driver.findElements(By.xpath("//div[@id='product_listing']/div/div/a[@class='block']")).get(i).click();
                titles.add(driver.getTitle().toString());
                driver.navigate().back();
                pages--;
                counter++;
            }

        }
//        System.out.println(titles);
//        System.out.println(counter);
    }
    @Ignore
    @Test
    public void test2_assertList(){

        for(String title:titles){

            Assert.assertTrue(title.contains("Table"));

        }


    }

    @Test
    public void test3_addAndEmptyCard()  {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();


        driver.get("https://www.webstaurantstore.com");
        driver.manage().window().maximize();
        driver.findElement(By.id("searchval")).sendKeys("stainless work table",Keys.ENTER);

        // to go to page 9
        driver.findElement(By.xpath("//a[contains(@aria-label,'last page')]")).click();
        // add page 9 items to the list
        List<WebElement> items= driver.findElements(By.xpath("//div[@id='product_listing']/div/div/a[@class='block']"));

        items.get(items.size()-1).click();

        //add to cart btn
        driver.findElement(By.id("buyButton")).click();

        // go to the cart btn
        driver.findElement(By.xpath("//a[@data-testid='cart-nav-link']")).click();

       WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='emptyCartButton btn btn-mini btn-ui pull-right']")));


        //empty cart btn
        driver.findElement(By.xpath("//button[@class='emptyCartButton btn btn-mini btn-ui pull-right']")).click();


        wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='flex-1 m-5 ']/../footer/button[1]")));


        driver.findElement(By.xpath("//*[@class='flex-1 m-5 ']/../footer/button[1]")).click();


        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='header-1']")));

        String textcart = driver.findElement(By.xpath("//*[@class='header-1']")).getText();
    Assert.assertEquals("Your cart is empty.",textcart);
    driver.quit();


    }


}